README file for QLP: TESS Lightcurves From The MIT Quick-Look Pipeline
MAST webpage: https://archive.stsci.edu/hlsp/qlp/
Refer to this HLSP with DOI: https://dx.doi.org/10.17909/t9-r086-e880

# INTRODUCTION
The Transiting Exoplanet Survey Satellite (TESS) is the first high-precision full-sky photometry survey in space. The MIT QLP team produces light curves from a magnitude limited (TESS magnitude < 13.5) set of stars and other stationary luminous objects from the TESS Full Frame Images (FFIs). The photometric precision roughly follows the theoretical predictions pre-launch. The data reduction process is described in the primary references (Huang et al. 2020a and Huang et al. 2020b). Additional pages in the full QLP data validation report provide additional metrics for decision-making. These plots are useful for diagnosing whether the source of transit-like variability is on target or from a nearby blended source, which is particularly important for FFI data.  Some of these data validation pages are available on the MIT TOI Portal.

The first data release consists of QLP light curves for targets in Sectors 1-26. These data products cover the two-year TESS Primary Mission and include 14,773,977 and 9,602,103 individual light curve segments in the Southern and Northern hemispheres, respectively. The second data release consists of 10-minute cadence light curves for 9.1 million stars from the first year of the Extended Mission (Sectors 27-39). Future deliveries of Extended Mission light curve data for Sectors 40 and onwards are expected to be released starting in 2022.

# DATA PRODUCTS
The light curve files have this data file naming convention:
  hlsp_qlp_tess_ffi_<sector>-<tid>_tess_v01_llc.<exten>

where:
  <sector> = The Sector represented as a 4-digit, zero-padded string, preceded by an 's', e.g., 's0026' for Sector 26.
  <tid> = The full, 16-digit, zeo-padded TIC ID.
  <exten> = The light curve data type, either "fits" or "txt".

The light curve tar bundles and sha256 checksum files have this file naming convention:
  hlsp_qlp_tess_ffi_<sector>_tess_v01_bulk-dl.<exten>

where:
  <sector> = The Sector represented as a 4-digit, zero-padded string, preceded by an 's', e.g., 's0026' for Sector 26.
  <exten> = The data file type, either ".tar.gz" or ".sha256".

Data file types:
_llc.fits | _llc.txt = QLP light curve. NOTE: .txt versions only available for Sectors 1-26, inclusive.
_bulk-dl.tar.gz = All QLP light curves for a given Sector.
_bulk-dl.sha256 = SHA256 checksum to verify successful download of the tar.gz file.
